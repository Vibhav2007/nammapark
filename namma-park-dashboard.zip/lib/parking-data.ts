export type ParkingLot = {
  id: string
  name: string
  area: string
  slotsLeft: number
  totalSlots: number
  baseRate: number
  surgeRate: number
  surge: boolean
  distanceKm: number
  /** normalized position on the map canvas, 0-100 */
  x: number
  y: number
}

export const PARKING_LOTS: ParkingLot[] = [
  {
    id: 'indiranagar-12th',
    name: 'Indiranagar 12th Main',
    area: 'Indiranagar',
    slotsLeft: 3,
    totalSlots: 60,
    baseRate: 40,
    surgeRate: 75,
    surge: true,
    distanceKm: 1.2,
    x: 68,
    y: 30,
  },
  {
    id: 'mg-road-metro',
    name: 'MG Road Metro Station',
    area: 'Central Bengaluru',
    slotsLeft: 20,
    totalSlots: 120,
    baseRate: 40,
    surgeRate: 55,
    surge: false,
    distanceKm: 0.4,
    x: 40,
    y: 52,
  },
  {
    id: 'koramangala-3rd',
    name: 'Koramangala 3rd Block',
    area: 'Koramangala',
    slotsLeft: 8,
    totalSlots: 90,
    baseRate: 40,
    surgeRate: 68,
    surge: true,
    distanceKm: 2.7,
    x: 55,
    y: 78,
  },
]
