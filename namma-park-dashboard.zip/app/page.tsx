'use client'

import { useState } from 'react'
import { CircleParking } from 'lucide-react'
import { PARKING_LOTS, type ParkingLot } from '@/lib/parking-data'
import { ParkingFeed } from '@/components/namma/parking-feed'
import { SciFiMap } from '@/components/namma/sci-fi-map'
import { BookingModal } from '@/components/namma/booking-modal'

export default function Page() {
  const [activeId, setActiveId] = useState<string | null>(null)
  const [modalLot, setModalLot] = useState<ParkingLot | null>(null)

  const select = (lot: ParkingLot) => {
    setActiveId(lot.id)
    setModalLot(lot)
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* ambient corner glows */}
      <div
        className="pointer-events-none absolute -left-40 top-20 h-96 w-96 rounded-full blur-[120px]"
        style={{ background: 'var(--neon-soft)' }}
        aria-hidden="true"
      />

      <div className="relative mx-auto flex min-h-screen max-w-7xl flex-col px-4 py-6 md:px-8 md:py-8">
        <header className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-2xl border border-neon/40 bg-neon/10 shadow-[0_0_28px_-6px_var(--neon)]">
              <CircleParking className="h-5 w-5 text-neon" />
            </span>
            <div>
              <h1 className="text-lg font-semibold tracking-tight">
                Namma<span className="text-neon">Park</span>
              </h1>
              <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
                Luxury Parking · Bengaluru
              </p>
            </div>
          </div>
          <div className="hidden items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 backdrop-blur-xl sm:flex">
            <span className="h-1.5 w-1.5 rounded-full bg-neon" />
            <span className="font-mono text-[11px] text-muted-foreground">
              All systems nominal
            </span>
          </div>
        </header>

        <div className="grid flex-1 gap-5 lg:grid-cols-[380px_1fr]">
          <ParkingFeed lots={PARKING_LOTS} activeId={activeId} onSelect={select} />
          <div className="min-h-[420px] lg:min-h-0">
            <SciFiMap lots={PARKING_LOTS} activeId={activeId} onSelect={select} />
          </div>
        </div>
      </div>

      <BookingModal
        lot={modalLot}
        onClose={() => {
          setModalLot(null)
          setActiveId(null)
        }}
      />
    </main>
  )
}
