'use client'

import { Activity } from 'lucide-react'
import type { ParkingLot } from '@/lib/parking-data'
import { ParkingCard } from './parking-card'

export function ParkingFeed({
  lots,
  activeId,
  onSelect,
}: {
  lots: ParkingLot[]
  activeId: string | null
  onSelect: (lot: ParkingLot) => void
}) {
  return (
    <section className="flex h-full flex-col gap-4">
      <header className="flex items-center gap-2">
        <span className="relative flex h-2 w-2">
          <span
            className="absolute inline-flex h-full w-full rounded-full bg-neon"
            style={{ animation: 'namma-ping-ring 1.8s ease-out infinite' }}
          />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-neon" />
        </span>
        <h2 className="font-mono text-xs uppercase tracking-[0.25em] text-muted-foreground">
          Live Feed · Bengaluru
        </h2>
      </header>

      <div className="flex flex-col gap-3 overflow-y-auto pr-1">
        {lots.map((lot) => (
          <ParkingCard
            key={lot.id}
            lot={lot}
            active={activeId === lot.id}
            onSelect={() => onSelect(lot)}
          />
        ))}
      </div>

      <footer className="mt-auto flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.02] px-3 py-2.5 backdrop-blur-xl">
        <Activity className="h-4 w-4 text-neon" />
        <p className="font-mono text-[11px] text-muted-foreground">
          Dynamic Pricing Engine{' '}
          <span className="text-neon">active</span> — rates adjust in real time.
        </p>
      </footer>
    </section>
  )
}
