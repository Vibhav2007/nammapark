'use client'

import { cn } from '@/lib/utils'
import type { ParkingLot } from '@/lib/parking-data'

function MapPin({
  lot,
  active,
  onSelect,
}: {
  lot: ParkingLot
  active: boolean
  onSelect: () => void
}) {
  const color = lot.surge ? 'var(--surge)' : 'var(--neon)'
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-label={`${lot.name}, ${lot.slotsLeft} slots available`}
      className="absolute -translate-x-1/2 -translate-y-1/2 outline-none"
      style={{ left: `${lot.x}%`, top: `${lot.y}%` }}
    >
      <span
        className="absolute left-1/2 top-1/2 h-10 w-10 -translate-x-1/2 -translate-y-1/2 rounded-full"
        style={{
          background: color,
          animation: 'namma-ping-ring 2s ease-out infinite',
          opacity: 0.5,
        }}
      />
      <span
        className={cn(
          'relative grid h-6 w-6 rotate-45 place-items-center rounded-[6px] border transition-transform duration-300',
          active ? 'scale-125' : 'group-hover:scale-110',
        )}
        style={{
          borderColor: color,
          background: 'color-mix(in oklch, black 55%, transparent)',
          boxShadow: `0 0 22px -2px ${color}`,
        }}
      >
        <span
          className="h-2 w-2 rounded-[2px]"
          style={{ background: color }}
        />
      </span>
      <span
        className={cn(
          'absolute left-1/2 top-full mt-2 -translate-x-1/2 whitespace-nowrap rounded-md border border-white/10 bg-black/70 px-2 py-1 font-mono text-[10px] text-foreground backdrop-blur-md transition-opacity duration-300',
          active ? 'opacity-100' : 'opacity-0',
        )}
      >
        ₹{lot.surgeRate}/hr
      </span>
    </button>
  )
}

export function SciFiMap({
  lots,
  activeId,
  onSelect,
}: {
  lots: ParkingLot[]
  activeId: string | null
  onSelect: (lot: ParkingLot) => void
}) {
  return (
    <div className="group relative h-full w-full overflow-hidden rounded-[1.75rem] border border-white/10 bg-black">
      {/* ambient glow */}
      <div
        className="pointer-events-none absolute -left-1/4 top-0 h-1/2 w-1/2 rounded-full blur-3xl"
        style={{ background: 'var(--neon-soft)' }}
        aria-hidden="true"
      />
      {/* grid */}
      <div
        className="absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
            'linear-gradient(to right, oklch(1 0 0 / 5%) 1px, transparent 1px), linear-gradient(to bottom, oklch(1 0 0 / 5%) 1px, transparent 1px)',
          backgroundSize: '44px 44px',
          maskImage:
            'radial-gradient(ellipse at center, black 55%, transparent 100%)',
        }}
        aria-hidden="true"
      />

      {/* stylized roads */}
      <svg
        className="absolute inset-0 h-full w-full"
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <g fill="none" stroke="oklch(1 0 0 / 9%)" strokeWidth="0.6">
          <path d="M-5 35 C 25 30, 45 55, 105 48" />
          <path d="M20 -5 C 30 30, 55 55, 48 105" />
          <path d="M-5 78 C 35 72, 60 82, 105 70" />
          <path d="M70 -5 C 66 30, 74 60, 62 105" />
        </g>
        <g fill="none" stroke="var(--neon)" strokeWidth="0.4" opacity="0.5">
          <path d="M20 -5 C 30 30, 55 55, 48 105" strokeDasharray="1.5 3" />
        </g>
      </svg>

      <div className="absolute left-4 top-4 z-10 rounded-full border border-white/10 bg-black/50 px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground backdrop-blur-md">
        Central Bengaluru · Grid
      </div>

      {lots.map((lot) => (
        <MapPin
          key={lot.id}
          lot={lot}
          active={activeId === lot.id}
          onSelect={() => onSelect(lot)}
        />
      ))}
    </div>
  )
}
