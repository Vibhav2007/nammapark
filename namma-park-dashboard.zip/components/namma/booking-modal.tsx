'use client'

import { useEffect, useState } from 'react'
import { Clock, MapPin, ShieldCheck, X, Zap } from 'lucide-react'
import type { ParkingLot } from '@/lib/parking-data'
import { GlowingQR } from './glowing-qr'
import { cn } from '@/lib/utils'

export function BookingModal({
  lot,
  onClose,
}: {
  lot: ParkingLot | null
  onClose: () => void
}) {
  const [reserved, setReserved] = useState(false)

  useEffect(() => {
    setReserved(false)
  }, [lot])

  useEffect(() => {
    if (!lot) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [lot, onClose])

  if (!lot) return null

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label={`Reserve a slot at ${lot.name}`}
    >
      <button
        type="button"
        aria-label="Close"
        onClick={onClose}
        className="absolute inset-0 bg-black/70 backdrop-blur-md animate-in fade-in"
      />

      <div className="relative z-10 w-full max-w-md overflow-hidden rounded-[1.75rem] border border-neon/25 bg-white/[0.04] p-6 shadow-[0_0_80px_-20px_var(--neon)] backdrop-blur-2xl duration-300 animate-in fade-in zoom-in-95">
        <div
          className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full blur-3xl"
          style={{ background: 'var(--neon-soft)' }}
          aria-hidden="true"
        />

        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
              <MapPin className="h-3 w-3 text-neon" />
              {lot.area}
            </div>
            <h2 className="mt-1 text-balance text-xl font-semibold text-foreground">
              {lot.name}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-white/10 text-muted-foreground transition-colors hover:border-neon/40 hover:text-neon"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-5 grid grid-cols-3 gap-3">
          <Stat
            label="Slots"
            value={`${lot.slotsLeft}`}
            hint="available"
            tone={lot.slotsLeft <= 5 ? 'surge' : 'neon'}
          />
          <Stat label="Rate" value={`₹${lot.surgeRate}`} hint="per hour" tone="neon" />
          <Stat label="Away" value={`${lot.distanceKm}`} hint="km" tone="plain" />
        </div>

        {lot.surge && (
          <div className="mt-3 flex items-center gap-2 rounded-2xl border border-neon/25 bg-neon/[0.06] px-3 py-2">
            <Zap className="h-4 w-4 fill-neon text-neon" />
            <p className="font-mono text-[11px] text-neon">
              Peak surge active — base ₹{lot.baseRate}/hr uplifted to ₹
              {lot.surgeRate}/hr.
            </p>
          </div>
        )}

        <div className="mt-5 grid grid-cols-[1fr_auto] items-center gap-4 rounded-2xl border border-white/10 bg-black/40 p-4">
          <div>
            <div className="flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-neon">
              <ShieldCheck className="h-3.5 w-3.5" />
              Contactless Check-in
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              Scan this secure code at the gate to unlock your reserved luxury
              slot.
            </p>
            <div className="mt-3 flex items-center gap-1.5 font-mono text-[11px] text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              Held for 15:00 min
            </div>
          </div>
          <div className="w-28">
            <GlowingQR seed={lot.id} />
          </div>
        </div>

        <button
          type="button"
          onClick={() => setReserved(true)}
          disabled={reserved}
          className={cn(
            'mt-5 w-full rounded-2xl border px-5 py-3.5 font-semibold tracking-wide transition-all duration-300',
            reserved
              ? 'border-neon/40 bg-neon/10 text-neon'
              : 'border-neon/40 bg-neon/15 text-neon shadow-[0_0_40px_-8px_var(--neon)] hover:bg-neon/25 hover:shadow-[0_0_55px_-8px_var(--neon)]',
          )}
        >
          {reserved ? '✓ Slot Reserved — QR Ready' : 'Reserve Luxury Slot'}
        </button>
      </div>
    </div>
  )
}

function Stat({
  label,
  value,
  hint,
  tone,
}: {
  label: string
  value: string
  hint: string
  tone: 'neon' | 'surge' | 'plain'
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.02] px-3 py-2.5 text-center">
      <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      <div
        className={cn(
          'mt-1 font-mono text-lg font-bold tabular-nums',
          tone === 'neon' && 'text-neon',
          tone === 'surge' && 'text-surge',
          tone === 'plain' && 'text-foreground',
        )}
      >
        {value}
      </div>
      <div className="font-mono text-[10px] text-muted-foreground">{hint}</div>
    </div>
  )
}
