'use client'

import { useMemo } from 'react'

// Deterministic pseudo-QR pattern derived from a seed string.
function buildMatrix(seed: string, size = 21) {
  let h = 2166136261
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  const rand = () => {
    h ^= h << 13
    h ^= h >>> 17
    h ^= h << 5
    return ((h >>> 0) % 1000) / 1000
  }
  const cells: boolean[] = []
  for (let i = 0; i < size * size; i++) cells.push(rand() > 0.5)

  const isFinder = (r: number, c: number) => {
    const inBox = (br: number, bc: number) =>
      r >= br && r < br + 7 && c >= bc && c < bc + 7
    return inBox(0, 0) || inBox(0, size - 7) || inBox(size - 7, 0)
  }
  const finderVal = (r: number, c: number) => {
    const local = (br: number, bc: number) => {
      const rr = r - br
      const cc = c - bc
      if (rr === 0 || rr === 6 || cc === 0 || cc === 6) return true
      if (rr >= 2 && rr <= 4 && cc >= 2 && cc <= 4) return true
      return false
    }
    if (r < 7 && c < 7) return local(0, 0)
    if (r < 7 && c >= size - 7) return local(0, size - 7)
    return local(size - 7, 0)
  }

  return { size, cells, isFinder, finderVal }
}

export function GlowingQR({ seed }: { seed: string }) {
  const { size, cells, isFinder, finderVal } = useMemo(
    () => buildMatrix(seed),
    [seed],
  )
  const unit = 100 / size

  return (
    <div className="relative aspect-square w-full overflow-hidden rounded-2xl border border-neon/30 bg-black p-3 shadow-[0_0_40px_-8px_var(--neon)]">
      <div
        className="pointer-events-none absolute inset-x-0 top-0 z-10 h-8 bg-gradient-to-b from-neon/40 to-transparent"
        style={{ animation: 'namma-scan 3.2s linear infinite' }}
        aria-hidden="true"
      />
      <svg
        viewBox="0 0 100 100"
        className="h-full w-full"
        role="img"
        aria-label="Check-in QR code"
      >
        {Array.from({ length: size }).map((_, r) =>
          Array.from({ length: size }).map((__, c) => {
            const idx = r * size + c
            const on = isFinder(r, c) ? finderVal(r, c) : cells[idx]
            if (!on) return null
            return (
              <rect
                key={`${r}-${c}`}
                x={c * unit + unit * 0.08}
                y={r * unit + unit * 0.08}
                width={unit * 0.84}
                height={unit * 0.84}
                rx={unit * 0.2}
                fill="var(--neon)"
              />
            )
          }),
        )}
      </svg>
    </div>
  )
}
