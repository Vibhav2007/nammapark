'use client'

import { MapPin, Navigation, Zap } from 'lucide-react'
import type { ParkingLot } from '@/lib/parking-data'
import { cn } from '@/lib/utils'

function SlotBadge({ lot }: { lot: ParkingLot }) {
  const low = lot.slotsLeft <= 5
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-xs font-medium tabular-nums',
        low
          ? 'border-surge/40 bg-surge/10 text-surge shadow-[0_0_18px_-4px_var(--surge)]'
          : 'border-neon/40 bg-neon/10 text-neon shadow-[0_0_18px_-4px_var(--neon)]',
      )}
    >
      <span
        className={cn('h-1.5 w-1.5 rounded-full', low ? 'bg-surge' : 'bg-neon')}
        style={{ animation: 'namma-pulse 1.6s ease-in-out infinite' }}
      />
      {low ? `${lot.slotsLeft} Slots Left` : `${lot.slotsLeft} Vacant`}
    </span>
  )
}

export function ParkingCard({
  lot,
  active,
  onSelect,
}: {
  lot: ParkingLot
  active: boolean
  onSelect: () => void
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        'group w-full rounded-3xl border bg-white/[0.03] p-4 text-left backdrop-blur-xl transition-all duration-300',
        'hover:bg-white/[0.06] hover:shadow-[0_0_50px_-16px_var(--neon)]',
        active
          ? 'border-neon/50 bg-white/[0.06] shadow-[0_0_50px_-16px_var(--neon)]'
          : 'border-white/10',
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
            <MapPin className="h-3 w-3 text-neon" />
            {lot.area}
          </div>
          <h3 className="mt-1 text-balance text-base font-semibold text-foreground">
            {lot.name}
          </h3>
        </div>
        <SlotBadge lot={lot} />
      </div>

      <div className="mt-4 flex items-end justify-between">
        <div className="flex items-baseline gap-2">
          <span className="font-mono text-sm text-muted-foreground line-through decoration-muted-foreground/60">
            ₹{lot.baseRate}/hr
          </span>
          <span
            className={cn(
              'font-mono text-2xl font-bold tabular-nums',
              lot.surge ? 'text-neon' : 'text-foreground',
            )}
            style={
              lot.surge
                ? { animation: 'namma-pulse 2s ease-in-out infinite' }
                : undefined
            }
          >
            ₹{lot.surgeRate}
            <span className="text-sm font-normal text-muted-foreground">/hr</span>
          </span>
        </div>

        {lot.surge ? (
          <span className="inline-flex items-center gap-1 rounded-full border border-neon/40 bg-neon/10 px-2 py-1 font-mono text-[10px] font-semibold uppercase tracking-widest text-neon shadow-[0_0_16px_-4px_var(--neon)]">
            <Zap className="h-3 w-3 fill-neon" />
            Peak Surge
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 font-mono text-[11px] text-muted-foreground">
            <Navigation className="h-3 w-3" />
            {lot.distanceKm} km
          </span>
        )}
      </div>
    </button>
  )
}
